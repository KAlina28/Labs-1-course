#ifndef LABS_KRYLOVA_TEST_SRC_H
#define LABS_KRYLOVA_TEST_SRC_H

void test_strcpy();
void test_strcmp();
void test_strcat();
void test_strlen();

#endif //LABS_KRYLOVA_TEST_SRC_H
