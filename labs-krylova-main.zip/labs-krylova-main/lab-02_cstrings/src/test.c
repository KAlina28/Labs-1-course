#include "test_str.h"

int main(){
    test_strcpy();
    test_strcmp();
    test_strcat();
    test_strlen();
    return 0;

}
