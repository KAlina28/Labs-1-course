#ifndef HW_02_HUFFMAN_UTIL_H
#define HW_02_HUFFMAN_UTIL_H

#include <string>

unsigned char converter(std::string str);
bool compare(const std::string& first_file, const std::string& second_file);


#endif //HW_02_HUFFMAN_UTIL_H
