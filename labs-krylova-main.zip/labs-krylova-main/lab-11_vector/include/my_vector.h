#ifndef LAB_11_VECTOR_MY_VECTOR_H
#define LAB_11_VECTOR_MY_VECTOR_H

#include "my_vector.hpp"

#endif //LAB_11_VECTOR_MY_VECTOR_H
