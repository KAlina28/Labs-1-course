//
// Created by Алина Крылова on 14.11.2022.
//

#ifndef LABS_KRYLOVA_UTIL_H
#define LABS_KRYLOVA_UTIL_H

double max(double a, double b);

#endif //LABS_KRYLOVA_UTIL_H
