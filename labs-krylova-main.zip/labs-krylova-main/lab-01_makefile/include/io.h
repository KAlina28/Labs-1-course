//
// Created by Алина Крылова on 14.11.2022.
//

#ifndef LABS_KRYLOVA_IO_H
#define LABS_KRYLOVA_IO_H

void logDebug(char a);

#endif //LABS_KRYLOVA_IO_H
