#include "io.h"
void logDebug(char s) {
    char c = s;
    s = c;
}


