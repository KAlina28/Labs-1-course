#include "algorithm.h"
#include "util.h"
#include "io.h"

double doComputation(double a, double  b) {
  double c = max(a, b);
  logDebug('d');
  return c;
}
